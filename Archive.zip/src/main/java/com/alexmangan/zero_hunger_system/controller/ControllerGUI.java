package com.alexmangan.zero_hunger_system.controller;

//Reference used for some JPanel help was Geeksforgeeks 
// Java Swing - JPanel with Examples
// https://www.geeksforgeeks.org/java/java-swing-jpanel-with-examples/

import com.alexmangan.zero_hunger_system.inventory.*;
import com.alexmangan.zero_hunger_system.demand.*;
import com.alexmangan.zero_hunger_system.allocation.*;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.awt.Dimension;
import java.awt.Insets;

//Swing GUI compoinents, from sample project
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class ControllerGUI implements ActionListener {

	//From GUI Sample. , this is where users will type 
	//and where we will show responses
    private JTextField regionInventory, replyInventory;
    private JTextField regionDemand, replyDemand;
    private JTextField regionAllocation, replyAllocation;

    //main method for launching th GUI
    public static void main(String[] args) {
        ControllerGUI gui = new ControllerGUI();
        gui.build(); //Build and show the GUI
    }

    private void build() {
    	//from sample
        JFrame frame = new JFrame("Zero Hunger Controller");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //exits the app once the window closes

        JPanel panel = new JPanel();
        //viuals, this is to stack the services vertically
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        //creates a a border for the panel 
        panel.setBorder(new EmptyBorder(new Insets(30, 80, 30, 80)));
        

        panel.add(getInventoryPanel());// adds inventory
        panel.add(getDemandPanel()); //adds demand
        panel.add(getAllocationPanel()); //adds location
        
		// Set size for the frame
		//frame.setSize(300, 300); //unnecessary 

		// Set the window to be visible as the default to be false
        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }

    private JPanel getInventoryPanel() {
    	//This piece builds the inventory panel user interface. 
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
        //`horizontsl layout - help from Geeks for Geeks as referenced

        //Create the label prompting to inoput the region to check the inventory of. 
        panel.add(new JLabel("Region (Inventory):"));
        //adds in a spacer
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        //Creates the input box for region
        regionInventory = new JTextField("", 10);
        panel.add(regionInventory);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        //button to trigger to check the inventory. 
        //following sample GUI from Sample Project 
        JButton button = new JButton("Check Inventory");
        button.addActionListener(this);
        panel.add(button);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        //This is the output box
        replyInventory = new JTextField("", 25);
        replyInventory.setEditable(false); // makes it read only
        panel.add(replyInventory);

        return panel;
    }

    private JPanel getDemandPanel() {
    	//This piece builds the inventory panel user interface. 
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
        //`horizontal layout - help from Geeks for Geeks as referenced

        //Create the label prompting to inoput the region to check the demand 
        panel.add(new JLabel("Region (Demand):"));
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

      //Creates the input box for demand
        regionDemand = new JTextField("", 10);
        panel.add(regionDemand);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        //button to trigger to check the demand. 
        //following sample GUI from Sample Project 
        JButton button = new JButton("Check Demand");
        button.addActionListener(this);
        panel.add(button);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        //This is the output box
        replyDemand = new JTextField("", 25);
        replyDemand.setEditable(false);// makes it read only
        panel.add(replyDemand);

        return panel;
    }

    private JPanel getAllocationPanel() {
    	//This piece builds the allocation panel user interface. 
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));

        //Create the label prompting to inoput the region to check the demand 
        panel.add(new JLabel("Region (Allocation):"));
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        regionAllocation = new JTextField("", 10);
        panel.add(regionAllocation);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        //button to trigger to check the Allocation. 
        //following sample GUI from Sample Project 
        JButton button = new JButton("Get Allocations");
        button.addActionListener(this);
        panel.add(button);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        //This is the output box
        replyAllocation = new JTextField("", 25);
        replyAllocation.setEditable(false);
        panel.add(replyAllocation);

        return panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton)e.getSource();
        String label = button.getText();

        
        //inventory request
        if (label.equals("Check Inventory")) {
            String region = regionInventory.getText().trim().toLowerCase();
            try {
            	//Connects to the inventory GRPC service
                ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50051).usePlaintext().build();
                InventoryServiceGrpc.InventoryServiceBlockingStub stub = InventoryServiceGrpc.newBlockingStub(channel);

                //Builds  and sends request
                InventoryQuery request = InventoryQuery.newBuilder().setRegion(region).build();
                Iterator<InventoryResult> responses = stub.getInventoryLevel(request);

                StringBuilder reply = new StringBuilder();
                while (responses.hasNext()) { // Gets the results from service
                    InventoryResult res = responses.next();
                    reply.append(res.getItem()).append(": ").append(res.getQtyKg()).append(" kg | ");
                }
                replyInventory.setText(reply.toString());
                //reply Inventory creates string - This shows the result
                channel.shutdown();
            } catch (Exception ex) {
            	// try / catch error handling
                replyInventory.setText("Error contacting Inventory service.");
                ex.printStackTrace();
            }

        } else if (label.equals("Check Demand")) {
            String region = regionDemand.getText().trim().toLowerCase();
            try {
                ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50052).usePlaintext().build();
                DemandServiceGrpc.DemandServiceBlockingStub stub = DemandServiceGrpc.newBlockingStub(channel);

                DemandQuery request = DemandQuery.newBuilder().setRegion(region).build();
                DemandResult result = stub.getDemand(request);

                // creates string - This shows the result
                replyDemand.setText("Demand: " + result.getDemand());
                channel.shutdown();
            } catch (Exception ex) { //error handling
                replyDemand.setText("Error contacting Demand service.");
                ex.printStackTrace();
            }

        } else if (label.equals("Get Allocations")) {
            String region = regionAllocation.getText().trim().toLowerCase();
            try {
                ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50053).usePlaintext().build();
                AllocationServiceGrpc.AllocationServiceBlockingStub stub = AllocationServiceGrpc.newBlockingStub(channel);

                RegionRequest request = RegionRequest.newBuilder().setRegion(region).build();
                Iterator<Allocation> allocations = stub.calculateAllocations(request);

                StringBuilder reply = new StringBuilder();
                while (allocations.hasNext()) {
                    Allocation alloc = allocations.next();
                    reply.append(alloc.getItem()).append(": ").append(alloc.getAllocatedQtyKg()).append(" kg | ");
                }
                replyAllocation.setText(reply.toString()); // creates string - This shows the result
                channel.shutdown();
            } catch (Exception ex) { //error handling
                replyAllocation.setText("Error contacting Allocation service.");
                ex.printStackTrace();
            }
        }
    }
}
