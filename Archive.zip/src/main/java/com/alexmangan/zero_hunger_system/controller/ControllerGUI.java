package com.alexmangan.zero_hunger_system.controller;

import com.alexmangan.zero_hunger_system.inventory.*;
import com.alexmangan.zero_hunger_system.demand.*;
import com.alexmangan.zero_hunger_system.allocation.*;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;

public class ControllerGUI implements ActionListener {

    private JTextField regionInventory, replyInventory;
    private JTextField regionDemand, replyDemand;
    private JTextField regionAllocation, replyAllocation;

    public static void main(String[] args) {
        ControllerGUI gui = new ControllerGUI();
        gui.build();
    }

    private void build() {
        JFrame frame = new JFrame("Zero Hunger Controller");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(new Insets(30, 80, 30, 80)));

        panel.add(getInventoryPanel());
        panel.add(getDemandPanel());
        panel.add(getAllocationPanel());

        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }

    private JPanel getInventoryPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));

        panel.add(new JLabel("Region (Inventory):"));
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        regionInventory = new JTextField("", 10);
        panel.add(regionInventory);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        JButton button = new JButton("Check Inventory");
        button.addActionListener(this);
        panel.add(button);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        replyInventory = new JTextField("", 25);
        replyInventory.setEditable(false);
        panel.add(replyInventory);

        return panel;
    }

    private JPanel getDemandPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));

        panel.add(new JLabel("Region (Demand):"));
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        regionDemand = new JTextField("", 10);
        panel.add(regionDemand);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        JButton button = new JButton("Check Demand");
        button.addActionListener(this);
        panel.add(button);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        replyDemand = new JTextField("", 25);
        replyDemand.setEditable(false);
        panel.add(replyDemand);

        return panel;
    }

    private JPanel getAllocationPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));

        panel.add(new JLabel("Region (Allocation):"));
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        regionAllocation = new JTextField("", 10);
        panel.add(regionAllocation);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        JButton button = new JButton("Get Allocations");
        button.addActionListener(this);
        panel.add(button);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));

        replyAllocation = new JTextField("", 25);
        replyAllocation.setEditable(false);
        panel.add(replyAllocation);

        return panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton)e.getSource();
        String label = button.getText();

        if (label.equals("Check Inventory")) {
            String region = regionInventory.getText().trim().toLowerCase();
            try {
                ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50051).usePlaintext().build();
                InventoryServiceGrpc.InventoryServiceBlockingStub stub = InventoryServiceGrpc.newBlockingStub(channel);

                InventoryQuery request = InventoryQuery.newBuilder().setRegion(region).build();
                Iterator<InventoryResult> responses = stub.getInventoryLevel(request);

                StringBuilder reply = new StringBuilder();
                while (responses.hasNext()) {
                    InventoryResult res = responses.next();
                    reply.append(res.getItem()).append(": ").append(res.getQtyKg()).append(" kg | ");
                }
                replyInventory.setText(reply.toString());
                channel.shutdown();
            } catch (Exception ex) {
                replyInventory.setText("Error contacting Inventory service.");
                ex.printStackTrace();
            }

        } else if (label.equals("Check Demand")) {
            String region = regionDemand.getText().trim().toLowerCase();
            try {
                ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50052).usePlaintext().build();
                DemandServiceGrpc.DemandServiceBlockingStub stub = DemandServiceGrpc.newBlockingStub(channel);

                DemandQuery request = DemandQuery.newBuilder().setRegion(region).build();
                DemandResult result = stub.getDemand(request);

                replyDemand.setText("Demand: " + result.getDemand());
                channel.shutdown();
            } catch (Exception ex) {
                replyDemand.setText("Error contacting Demand service.");
                ex.printStackTrace();
            }

        } else if (label.equals("Get Allocations")) {
            String region = regionAllocation.getText().trim().toLowerCase();
            try {
                ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50053).usePlaintext().build();
                AllocationServiceGrpc.AllocationServiceBlockingStub stub = AllocationServiceGrpc.newBlockingStub(channel);

                RegionRequest request = RegionRequest.newBuilder().setRegion(region).build();
                Iterator<Allocation> allocations = stub.calculateAllocations(request);

                StringBuilder reply = new StringBuilder();
                while (allocations.hasNext()) {
                    Allocation alloc = allocations.next();
                    reply.append(alloc.getItem()).append(": ").append(alloc.getAllocatedQtyKg()).append(" kg | ");
                }
                replyAllocation.setText(reply.toString());
                channel.shutdown();
            } catch (Exception ex) {
                replyAllocation.setText("Error contacting Allocation service.");
                ex.printStackTrace();
            }
        }
    }
}
