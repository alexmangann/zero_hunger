package com.alexmangan.zero_hunger_system.allocation;

//gRPC server
import java.io.IOException;
import io.grpc.Server;
import io.grpc.stub.StreamObserver;
import io.grpc.ServerBuilder;
import java.net.InetAddress;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

import com.alexmangan.zero_hunger_system.inventory.InventoryResponse;

public class AllocationServer extends AllocationServiceGrpc.AllocationServiceImplBase{
	
	public static void main(String[] args) throws IOException, InterruptedException {

		
		//Registers the service with jmDNS
        JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost()); //from DateServer lab
        ServiceInfo serviceInfo = ServiceInfo.create("_grpc._tcp.local.", "allocation", 50053, "desc- zero hunger allocation service");
        //This is the service tyope for grpc over TCP, Allocation is service name, 50053 is where it will run, added description
        jmdns.registerService(serviceInfo);
        System.out.println("Registered the AllocationService with jmDNS on 50053");
        
        int port = 50053;
        //Start gRPC server
        AllocationServer serverInstance = new AllocationServer();
        Server server = ServerBuilder.forPort(port)
				.addService(serverInstance)
				.build()
				.start();
        
        System.out.println("Allocation gRPC server has started on port 50053");
	    server.awaitTermination();
	}
	
	@Override
	public void calculateAllocations(RegionRequest request, StreamObserver<Allocation> responseObserver) {
		
		//hard coded logic for now
		String region = request.getRegion().toLowerCase();
		String message = "";
		
		if (region.equals("galway")) {
			
			//as used in strings lab
            responseObserver.onNext(Allocation.newBuilder().setItem("pasta").setAllocatedQtyKg(1.0).build());
            responseObserver.onNext(Allocation.newBuilder().setItem("rice").setAllocatedQtyKg(1.0).build());
			
		} else if (region.equals("dublin")) {	//hardcoded values for food distribution
				
            responseObserver.onNext(Allocation.newBuilder().setItem("pasta").setAllocatedQtyKg(0.8).build());
            responseObserver.onNext(Allocation.newBuilder().setItem("rice").setAllocatedQtyKg(0.9).build());
		}
			
        responseObserver.onCompleted();
        
  
		

	}
}