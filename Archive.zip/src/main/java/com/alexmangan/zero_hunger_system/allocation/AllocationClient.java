package com.alexmangan.zero_hunger_system.allocation;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import java.util.Iterator;
import java.util.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.JOptionPane;
import java.net.InetAddress;
import io.grpc.stub.StreamObserver;

//Taken from jmDNS tutorial lab

public class AllocationClient {

	private static class AllocationListener implements ServiceListener {

		@Override
		public void serviceAdded(ServiceEvent event) {
			// for debugging, fires when a service is added

			System.out.println("Service added: " + event.getInfo());
		}

		@Override
		public void serviceRemoved(ServiceEvent event) {
			// Also for debugging, fires when a service gets removed
			System.out.println("Service removed: " + event.getInfo());
		}

		@Override
		public void serviceResolved(ServiceEvent event) {
			// This one will fire when you connect and info about the service is available.
			// IPO, port etc.
			System.out.println("Service resolved: " + event.getInfo());

			try {

				// Get host and port form date client lab
				ServiceInfo info = event.getInfo();
				int port = info.getPort();
				String address = info.getHostAddresses()[0];

				// gRPC channel and blocking stub from the StringClient from string lab:
				ManagedChannel channel = ManagedChannelBuilder.forAddress(address, port).usePlaintext().build();
				// dynamic, not ghardcoded for jmDNS
				AllocationServiceGrpc.AllocationServiceBlockingStub blockingStub = AllocationServiceGrpc
						.newBlockingStub(channel);

				// Ask user for region using JOption Pane
				String region = JOptionPane.showInputDialog("Enter region:");
				// Create request with user input
				RegionRequest request = RegionRequest.newBuilder().setRegion(region).build();

				// Make gRPC Call. Server Streaming Response - from string lab
				Iterator<Allocation> response = blockingStub.calculateAllocations(request);
				// Server sends back multiple responses so we use iterator

				// Shows the first message:
				while (response.hasNext()) {
					Allocation a = response.next();
					System.out.println("Item: " + a.getItem() + ", Qty: " + a.getAllocatedQtyKg());
				}
				channel.shutdown();

			} catch (RuntimeException e) {
				// print out errors
				e.printStackTrace();
			}

		}
	}

	// main method from date client lab
	public static void main(String[] args) throws InterruptedException {
		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());
			// Add service listener
			jmdns.addServiceListener("_grpc._tcp.local.", new AllocationListener());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

	}
}
