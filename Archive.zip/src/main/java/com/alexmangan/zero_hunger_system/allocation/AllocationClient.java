package com.alexmangan.zero_hunger_system.allocation;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import java.util.Iterator;

public class AllocationClient {
    public static void main(String[] args) {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50053)
                .usePlaintext()
                .build();

        AllocationServiceGrpc.AllocationServiceBlockingStub blockingStub = AllocationServiceGrpc.newBlockingStub(channel);

        RegionRequest request = RegionRequest.newBuilder().setRegion("Galway").build();

        Iterator<Allocation> responseIterator = blockingStub.calculateAllocations(request);

        System.out.println("Allocations for region: " + request.getRegion());
        while (responseIterator.hasNext()) {
            Allocation alloc = responseIterator.next();
            System.out.println("Item: " + alloc.getItem() + ", Allocated Qty (kg): " + alloc.getAllocatedQtyKg());
        }

    }
}
