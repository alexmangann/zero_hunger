package com.alexmangan.zero_hunger_system.demand;

//gRPC server
import java.io.IOException;
import java.net.InetAddress;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

import io.grpc.Server;
import io.grpc.stub.StreamObserver;
import io.grpc.ServerBuilder;

public class DemandServer extends DemandServiceGrpc.DemandServiceImplBase{
	
	//main method for starting the gRPC server, as in Strings lab
	public static void main(String[]args) throws IOException, InterruptedException {
	
        JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost()); //from DateServer lab
        ServiceInfo serviceInfo = ServiceInfo.create("_grpc._tcp.local.", "demand", 50052, "desc- zero hunger demand server");
        //This is the service type for grpc over tpc, demand is the service name, 50052 is where it runs, demand server description), 
        jmdns.registerService(serviceInfo);
		
		//create an instance of a server
		DemandServer serverInstance = new DemandServer();
		
		//define where the server will listen (50052)
		int port = 50052;
		
		//build and start gRPC server.
		//Attach service
		Server server = ServerBuilder.forPort(port)
				.addService(serverInstance)
				.build()
				.start();
		
		System.out.println("Demand Server has started on port "+port);
		
	    server.awaitTermination();
	}
	
	//method that runs when client calls getDemand()
	@Override
	public void getDemand(DemandQuery request, StreamObserver<DemandResult> responseObserver) {
		//Get item that the client requested
		String region = request.getRegion().toLowerCase();
		int demand = 0;
		
		//hardcoded values for demand by region
		if (region.equals("galway")){
			demand = 100;
		} else if(region.equals("dublin")) {
			demand = 200;
		}
		
		//build response
		DemandResult result = DemandResult.newBuilder()
				.setRegion(region)
				.setDemand(demand)
				.build();
		
        responseObserver.onNext(result);
        responseObserver.onCompleted();

	}
}	
		 
		
