package com.alexmangan.zero_hunger_system.demand;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class DemandClient {
    public static void main(String[] args) {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50052)
                .usePlaintext()
                .build();

        DemandServiceGrpc.DemandServiceBlockingStub blockingStub = DemandServiceGrpc.newBlockingStub(channel);

        DemandQuery request = DemandQuery.newBuilder().setRegion("Galway").build();

        DemandResult result = blockingStub.getDemand(request);

        System.out.println("Demand for region: " + result.getRegion());
        System.out.println("People in need: " + result.getDemand());

    }
}
