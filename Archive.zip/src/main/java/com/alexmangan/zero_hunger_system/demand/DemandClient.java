package com.alexmangan.zero_hunger_system.demand;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import java.util.Iterator;
import java.util.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.JOptionPane;

import com.alexmangan.zero_hunger_system.demand.DemandServiceGrpc;


import java.net.InetAddress;
import io.grpc.stub.StreamObserver;

public class DemandClient{
	
	private static class DemandListener implements ServiceListener {
		
		@Override
		public void serviceAdded(ServiceEvent event) {
			// for debugging, fires when a service is added

			System.out.println("Service added: " + event.getInfo());
		}

		@Override
		public void serviceRemoved(ServiceEvent event) {
			// Also for debugging, fires when a service gets removed
			System.out.println("Service removed: " + event.getInfo());
		}

		@Override
		public void serviceResolved(ServiceEvent event) {
			// This one will fire when you connect and info about the service is available.
			// IPO, port etc.
			System.out.println("Service resolved: " + event.getInfo());

			try {

				// Get host and port form date client lab
				ServiceInfo info = event.getInfo();
				int port = info.getPort();
				String address = info.getHostAddresses()[0];

				// gRPC channel and blocking stub from the StringClient from string lab:
				ManagedChannel channel = ManagedChannelBuilder.forAddress(address, port).usePlaintext().build();
				// dynamic, not hardcoded for jmDNS
				DemandServiceGrpc.DemandServiceBlockingStub blockingStub = DemandServiceGrpc
						.newBlockingStub(channel);

				// Ask user for region using JOption Pane
				String region = JOptionPane.showInputDialog("Enter region:");
				// Create request with user input
				
				DemandQuery request = DemandQuery.newBuilder().setRegion(region).build();

				DemandResult response = blockingStub.getDemand(request);
				
				System.out.println("Region: " + response.getRegion() + ", Demand (population): " + response.getDemand());

				channel.shutdown();
				
			} catch (RuntimeException e) {
				// print out errors
				e.printStackTrace();
			}
		}
	}
			public static void main(String[] args) {
				try {
					JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());
					jmdns.addServiceListener("_grpc._tcp.local.", new DemandListener());
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}
	}
	
}