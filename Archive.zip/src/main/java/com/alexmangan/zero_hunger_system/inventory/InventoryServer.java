package com.alexmangan.zero_hunger_system.inventory;

//gRPC server
import java.io.IOException;
import java.net.InetAddress;

import io.grpc.Server;
import io.grpc.stub.StreamObserver;
import io.grpc.ServerBuilder;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

public class InventoryServer extends InventoryServiceGrpc.InventoryServiceImplBase{
	
	//main method for starting the gRPC server, as in Strings lab
	public static void main(String[]args) throws IOException, InterruptedException {
		
        JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost()); //from DateServer lab. 
        ServiceInfo serviceInfo = ServiceInfo.create("_grpc._tcp.local.", "inventory", 50051, "desc -zero hunger inventory server ");
        //This is the service tyope for grpc over TCP, Inventory is service name, 50051 is where it will run, added description
        jmdns.registerService(serviceInfo);
		
		
		int port = 50051; //define where the server will listen (50051)
		//create an instance of a server
		InventoryServer serverInstance = new InventoryServer();
		//build and start gRPC server.
		//Attach service
		Server server = ServerBuilder.forPort(port)
				.addService(serverInstance) //adds the service implpementation
				.build()
				.start();
		
		System.out.println("Inventory Server has started on port "+port);
		
	    server.awaitTermination(); //this will keep  the server running
	}
	
	//method that runs when client calls getInventory()
	@Override
	public void getInventoryLevel(InventoryQuery request, StreamObserver<InventoryResult> responseObserver) {
		//Get item that the client requested
		String region = request.getRegion().toLowerCase();
		
		//hardcoded values for food inventory per region
		
		if (region.equals("galway")) {
            responseObserver.onNext(InventoryResult.newBuilder().setItem("pasta").setQtyKg(500).build());
            responseObserver.onNext(InventoryResult.newBuilder().setItem("rice").setQtyKg(700).build());
		} else if (region.equals("dublin")) {	//hardcoded values for food inventory per region
				
            responseObserver.onNext(InventoryResult.newBuilder().setItem("pasta").setQtyKg(800).build());
            responseObserver.onNext(InventoryResult.newBuilder().setItem("rice").setQtyKg(1000).build());
		}
		
        responseObserver.onCompleted();
	}
}	
		 
		
