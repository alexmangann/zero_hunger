package com.alexmangan.zero_hunger_system.inventory;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import java.util.*;

public class InventoryClient{
		
	public static void main(String[] args) throws Exception {
		ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50051).usePlaintext().build();
	
		InventoryServiceGrpc.InventoryServiceBlockingStub blockingStub = InventoryServiceGrpc.newBlockingStub(channel);
		
        InventoryQuery request = InventoryQuery.newBuilder().setRegion("Galway").build();

        //from stringClient.java
        Iterator<InventoryResult> responseIterator = blockingStub.getInventoryLevel(request);
		
        System.out.println("Inventory for region: " + request.getRegion());
        while (responseIterator.hasNext()) {
            InventoryResult result = responseIterator.next();
            System.out.println("Item: " + result.getItem() + ", Qty (kg): " + result.getQtyKg());
        }

	}
}