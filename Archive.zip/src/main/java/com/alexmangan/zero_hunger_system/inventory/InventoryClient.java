package com.alexmangan.zero_hunger_system.inventory;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import java.util.Iterator;
import java.util.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;

import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;
import javax.swing.JOptionPane;

import com.alexmangan.zero_hunger_system.inventory.InventoryServiceGrpc;
import com.alexmangan.zero_hunger_system.inventory.InventoryQuery;
import com.alexmangan.zero_hunger_system.inventory.InventoryResult;


import io.grpc.ManagedChannelBuilder;
import java.util.*;

public class InventoryClient {

	private static class InventoryListener implements ServiceListener {

		@Override
		public void serviceAdded(ServiceEvent event) {
			// for debugging, fires when a service is added

			System.out.println("Service added: " + event.getInfo());
		}

		@Override
		public void serviceRemoved(ServiceEvent event) {
			// Also for debugging, fires when a service gets removed
			System.out.println("Service removed: " + event.getInfo());
		}

		@Override
		public void serviceResolved(ServiceEvent event) {
			// This one will fire when you connect and info about the service is available.
			// IPO, port etc.
			System.out.println("Service resolved: " + event.getInfo());

			try {

				// Get host and port form date client lab
				ServiceInfo info = event.getInfo();
				int port = info.getPort();
				String address = info.getHostAddresses()[0];

				// gRPC channel and blocking stub from the StringClient from string lab:
				ManagedChannel channel = ManagedChannelBuilder.forAddress(address, port).usePlaintext().build();
				// dynamic, not hardcoded for jmDNS
				InventoryServiceGrpc.InventoryServiceBlockingStub blockingStub = InventoryServiceGrpc
						.newBlockingStub(channel);
				// Ask user for region using JOption Pane
				String region = JOptionPane.showInputDialog("Enter region:");
				// Create request with user input

				InventoryQuery request = InventoryQuery.newBuilder().setRegion(region).build();

				// Make gRPC Call. Server Streaming Response - from string lab
				Iterator<InventoryResult> response = blockingStub.getInventoryLevel(request);
				// Server sends back multiple responses so we use iterator

				System.out.println("Inventory for region: " + region);
				while (response.hasNext()) {
					InventoryResult result = response.next();
					System.out.println("Item: " + result.getItem() + ", Qty (kg): " + result.getQtyKg());
				}
				channel.shutdown();

			} catch (RuntimeException e) {
				// print out errors
				e.printStackTrace();
			}

		}

	}

	// main method from date client lab
	public static void main(String[] args) {
		try {
			// Create a JmDNS instance
			JmDNS jmdns = JmDNS.create(InetAddress.getLocalHost());
			// Add service listener
			jmdns.addServiceListener("_grpc._tcp.local.", new InventoryListener());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}