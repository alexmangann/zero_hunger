
package com.alexmangan.zero_hunger_system.controller;

import com.alexmangan.zero_hunger_system.allocation.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.alexmangan.zero_hunger_system.allocation.AllocationServiceGrpc;
import com.alexmangan.zero_hunger_system.allocation.RegionRequest;
import com.alexmangan.zero_hunger_system.allocation.Allocation;

public class ControllerGUI {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Zero Hunger Controller");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // GUI components
        JLabel regionLabel = new JLabel("Enter Region:");
        JTextField regionField = new JTextField(20);
        JButton computeBtn = new JButton("Compute Allocations");
        JTextArea resultArea = new JTextArea(10, 30);
        resultArea.setEditable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.add(regionLabel);
        panel.add(regionField);
        panel.add(computeBtn);
        panel.add(new JScrollPane(resultArea));

        frame.getContentPane().add(panel);
        frame.setVisible(true);

        // Button Action
        computeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String region = regionField.getText().trim().toLowerCase();

                if (region.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter a region.");
                    return;
                }

                // Connect to Allocation Service
                try {
                    ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50053)
                            .usePlaintext()
                            .build();

                    AllocationServiceGrpc.AllocationServiceBlockingStub stub =
                            AllocationServiceGrpc.newBlockingStub(channel);

                    RegionRequest request = RegionRequest.newBuilder().setRegion(region).build();
                    Iterator<Allocation> allocations = stub.calculateAllocations(request);

                    StringBuilder results = new StringBuilder("Allocations for " + region + ":\n");
                    while (allocations.hasNext()) {
                        Allocation alloc = allocations.next();
                        results.append(alloc.getItem())
                               .append(": ")
                               .append(alloc.getAllocatedQtyKg())
                               .append(" kg\n");
                    }
                    resultArea.setText(results.toString());


                    channel.shutdown();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    resultArea.setText("Failed to contact Allocation Service.");
                }
            }
        });
    }
}
